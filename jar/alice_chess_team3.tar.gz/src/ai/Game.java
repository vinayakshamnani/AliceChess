package ai;


/**
 * Created by Chang on 10/15/2016.
 */
public class Game {
    public static void main1(String[] args){
    	// Moved to main.Main
    }
}
